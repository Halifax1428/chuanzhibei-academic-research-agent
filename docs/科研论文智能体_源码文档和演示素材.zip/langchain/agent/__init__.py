"""Research Agent application package."""
